import { Component, OnInit } from '@angular/core';
import { CarroService } from '../services/carro.service';


@Component({
  selector: 'app-carro',
  templateUrl: './carro.component.html',
  styleUrls: ['./carro.component.css']
})
export class CarroComponent implements OnInit {

  kmVelocidad: string = '';
  accion: string = '';

  constructor(
    private CarroSrv: CarroService
  ) { }

  ngOnInit() {
  }

  acelerar() {
    this.kmVelocidad = '255';
    this.accion = 'acelerar';
    const data: any = {
      'kmVelocidad': this.kmVelocidad,
      'accion': this.accion
    };

    this.CarroSrv.Acelerar(data)
      .subscribe(data => {
        console.log(data);
      },
        error => {
          console.log('Error', error);
        }
      );
  }

  frenar() {
    this.kmVelocidad = '0';
    this.accion = 'frenar';
    const data: any = {
      'kmVelocidad': this.kmVelocidad,
      'accion': this.accion
    };

    this.CarroSrv.Frenar(data)
      .subscribe(data => {
        console.log(data);
      },
        error => {
          console.log('Error', error);
        }
      );
  }

  retroceder() {
    this.kmVelocidad = '150';
    this.accion = 'retroceder';
    const data: any = {
      'kmVelocidad': this.kmVelocidad,
      'accion': this.accion
    };

    this.CarroSrv.Frenar(data)
      .subscribe(data => {
        console.log(data);
      },
        error => {
          console.log('Error', error);
        }
      );
  }
  Derecha() {
    this.kmVelocidad = '150';
    this.accion = 'derecha';
    const data: any = {
      'kmVelocidad': this.kmVelocidad,
      'accion': this.accion
    };

    this.CarroSrv.Derecha(data)
      .subscribe(data => {
        console.log(data);
      },
        error => {
          console.log('Error', error);
        }
      );
  }


}
