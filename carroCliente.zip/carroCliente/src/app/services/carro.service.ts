import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';

@Injectable({
  providedIn: 'root'
})
export class CarroService {

  constructor(private http: HttpClient) { }

  public Acelerar(data: any) {
    return this.http.post('http://localhost:3500/motor', data);
  }

  public Frenar(data: any) {
    return this.http.post('http://localhost:3500/motor', data);
  }
  public Derecha(data: any) {
    return this.http.post('http://localhost:3500/motor', data);
  }

  public Izquierda(data: any) {
    return this.http.post('http://localhost:3500/motor', data);
  }

}
